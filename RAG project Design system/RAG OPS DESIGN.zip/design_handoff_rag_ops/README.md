# Handoff: RAG Ops Dashboard

## Overview

**RAG Ops** is an AI observability dashboard for a Retrieval-Augmented Generation system. It surfaces retrieval quality, generation quality, and product metrics across eval runs so a team can iterate on their RAG pipeline with confidence. The product targets ML/AI product managers and engineers who already know what *precision@5* and *MRR* mean — direct, technical, calm.

This handoff covers the entire app: 6 top-level routes, all loading/empty/error states, every interaction described in the user-journey spec.

## About the Design Files

The files under `design_reference/` are **design references created in HTML** — a runnable React+Babel prototype showing the intended look and behavior. **They are not production code to copy directly.**

The task is to recreate these designs in the target codebase's existing environment (React + TypeScript + your styling system of choice — Tailwind / CSS Modules / styled-components / etc.). If no environment exists yet, the spec was authored against React + Vite + plain CSS variables, which is a reasonable starting point.

To preview the prototype: open `design_reference/index.html` in a browser (or run a static file server in that folder — Babel + ES modules need an HTTP origin in some browsers).

## Fidelity

**High-fidelity.** Final colors, typography, spacing, radii, transitions, and copy. Treat hex values, font weights, animation durations, and microcopy as locked. The mock uses real data shapes (eval_runs, eval_results, queries) — port those shapes; do not invent new ones.

The two non-final aspects:
1. **Icons** — Tabler Icons webfont. Swap to `lucide-react` in production (visual mapping in the design system spec; same 1.5 px / 24 px family).
2. **Charts** — hand-rolled SVG. Replace with Recharts / Visx / nivo as appropriate; preserve the visual specs (accent line, optional fill gradient, current-run-highlighted dots, target reference lines).

---

## Architecture overview

```
URL                              Page component
/search                          SearchPage              (default landing)
/dashboard/retrieval             RetrievalPage
/dashboard/generation            GenerationPage
/dashboard/metrics               MetricsPage
/eval-runs                       EvalRunsPage
/eval-runs/compare?a=&b=         EvalRunsPage → CompareView
/settings                        SettingsPage
```

**Persistent app shell:**
- Sidebar (left, 220 px, sticky, full-height) — always visible on desktop. Active nav item gets `--accent-surface` background + `--accent-text` text.
- Main content area (flex: 1, `--bg-page` background, 24 px / 28 px padding) — content max-width capped at `--content-max-width`.

**Global state (persists across navigation):**
- `selectedEvalRunId` — defaults to most-recent run. Shared by Retrieval / Generation dashboards.
- `theme` — `"light"` or `"dark"`, persisted in `localStorage["rag-ops-theme"]`. Applied via `data-theme` attribute on `<html>`.

**Page-level state** resets on navigation.

**Data fetching pattern (recommended):** React Query / SWR — stale-while-revalidate so cached dashboards paint instantly, fresh data fills in. Refetch dashboards when `selectedEvalRunId` changes.

---

## Design tokens

All tokens are defined in `design_reference/src/colors_and_type.css` under `:root[data-theme="light"]` and `:root[data-theme="dark"]`. Port these one-for-one into your token system (CSS variables, Tailwind config, or a TS object).

### Color tokens (light theme)

| Token | Value | Use |
|---|---|---|
| `--bg-page`    | `#F7F7F5` | Page background (warm off-white, NOT pure white) |
| `--bg-card`    | `#FFFFFF` | Floating cards & panels |
| `--bg-surface` | `#F1EFE8` | Metric cards, inputs, inset areas |
| `--bg-hover`   | `#ECEAE3` | Hover state on surfaces |
| `--text-primary`   | `#1A1A1A` | Body text |
| `--text-secondary` | `#5F5E5A` | Secondary copy |
| `--text-tertiary`  | `#9B97A0` | Labels, metadata |
| `--accent`            | `#0F6E56` | Primary CTAs, active nav, trend line — **used sparingly** |
| `--accent-hover`      | `#085041` | Button hover |
| `--accent-surface`    | `#E1F5EE` | Citation pills, active-nav bg, highlighted source border |
| `--accent-text`       | `#085041` | Text on accent-surface |
| `--accent-text-light` | `#0F6E56` | Inline accent links |
| `--success` | `#0F6E56`, `--success-surface` `#E1F5EE`, `--success-text` `#085041` |
| `--warning` | `#BA7517`, `--warning-surface` `#FAEEDA`, `--warning-text` `#633806` |
| `--danger`  | `#D04F4F`, `--danger-surface`  `#FBE7E7`, `--danger-text`  `#7A1F1F` |
| `--info`    | `#3A6EA5`, `--info-surface`    `#E2ECF8`, `--info-text`    `#1F3F66` |
| `--purple`  | `#6B47B5`, `--purple-surface`  `#EBE2FA`, `--purple-text`  `#3F2480` |

The full set lives in `design_reference/src/colors_and_type.css` — copy it as your source of truth.

### Borders & radii

- Borders: almost always `0.5px solid var(--border-light)` (~6% black). Hover bumps to `--border-medium` (~10%). Active (focused inputs, highlighted source) uses `--border-active` (= accent).
- Radii: `--radius-sm 6px` · `--radius-md 10px` · `--radius-lg 12px` · `--radius-xl 16px` · `--radius-pill 999px`. **Nothing rounder than 16 px** except pills.

### Shadows

**Light theme uses no card shadows.** The border + tinted page background provides depth. Dark theme may use a subtle shadow. Toast notifications get `0 8px 24px rgba(20,20,20,0.06)`. Focus rings on the search bar use `0 0 0 3px rgba(15,110,86,0.08)`.

### Typography

```
Display body: Plus Jakarta Sans (400, 500, 600). 600 only for page titles.
Numbers / paths / latencies / citations: JetBrains Mono (400, 500).
```

No font-weight 700 anywhere. Body text always left-aligned. Load via Google Fonts (`Plus+Jakarta+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500`).

**Scale:**
- Page title: 22 px / 500 / -0.01em
- Card label (uppercase): 11 px / 500 / 0.03em letter-spacing
- Metric value: 24 px / 500 / mono / line-height 1
- Body / answer text: 14 px / line-height 1.8
- Table cell: 13 px / 400
- Subtitle / desc: 12–13 px / `--text-tertiary`
- Mini-label: 10 px / 500 / uppercase / 0.05em

### Spacing

4 px base. Common rhythm: 4 / 8 / 12 / 16 / 20 / 24 / 28 / 36.
- Card padding: 16 px header / 18 px body / 20 px horizontal.
- Section gap (between panels): 20 px.
- Major-region gap: 24 px.

### Iconography

Tabler Icons in the mock; production should use **`lucide-react`** (same 1.5 px / 24 px family). Sizes: nav 17 px · inline-with-text 15 px · standalone 18–20 px · empty states 28–40 px · badge/pill 11 px. Full Tabler → Lucide mapping is in the spec ("Iconography" section).

**No emoji. No unicode-as-icon. No bespoke SVG decoration.**

### Animation

Crisp, never bouncy.
- Color / border / background: `200ms ease`
- Layout changes: `300ms ease`
- Chart mount & bar fills: `400ms ease-out` (bars grow from `width: 0`)
- Failure-row expand/collapse: `250ms ease`
- Search-results entry: fade-up from 10 px, `300ms`, staggered 50 ms
- Skeleton shimmer: `1.5s ease-in-out infinite`
- Toast in/out: 300 ms

**No spring physics. No overshoots. No press/shrink scale.**

---

## Components inventory

Implement these as named, typed components. The mock has them in `design_reference/src/components.jsx` and `design_reference/src/extras.jsx`.

### Layout primitives
- **`<Sidebar>`** — 220 px wide, sticky, full-height. Logo + 3 nav sections (Main / Evaluation / System), bottom-pinned theme toggle + build info.
- **`<PageHeader>`** — title + subtitle on the left, page controls (tabs, run selector) on the right.
- **`<Panel>`** — white card, `0.5px` border, `--radius-xl` (16 px), no shadow. Has a `panel-header` (16 px / 20 px padding, with title + subtitle + optional right slot) and a `panel-body` (18 px / 20 px padding).

### Data visualization
- **`<MetricCard>`** — `--bg-surface` (tinted) background, **no border**, `--radius-lg`. Label (uppercase, 11 px), delta pill (top-right), value (24 px mono), desc (12 px tertiary). Hallucination cards use `value.danger` (`--danger` color).
- **`<Delta>`** — pill with `ti-trending-up` / `ti-trending-down` icon. Variants: `success`, `danger`, `neutral` ("no change").
- **`<BarRow>`** — label (110 px right-aligned) · 8 px track · numeric value (mono, right-aligned). Fill color thresholded by score: ≥0.70 success, ≥0.50 warning, <0.50 danger.
- **`<TrendChart>` / `<HighlightedTrendChart>`** — hand-rolled SVG, 600×130 viewBox, 30 px left margin. Stroke `--accent`, fill `accent @ 16% → 0%` gradient. Dots at 4.5 px radius; **selected run gets r=7 + an 11 px translucent accent halo**. Hover dot → tooltip with run name + value. Optional dashed target reference line (`--text-tertiary` @ 0.6 opacity, `stroke-dasharray: 3 3`).
- **`<BarChart>`** — daily query volume. Flex of bars, height proportional to max, `--accent` fill, growth animation 400 ms with `${i*12}ms` stagger.
- **`<ScoreHistogram>`** — 4-column grid (gap 24 px). Each column: title + bars (1–5 scale, 20 px wide) + axis. Hallucination column is binary (No/Yes, 40 px wide bars, success/danger).

### Search & results
- **`<SourceCard>`** — 14 px / 16 px padding, white. Name + score (top row), 4 px score-bar track, mono path, 3-line clamped content preview, "View original" external-link affordance. **Active state:** 1.5 px accent border + `0 0 0 3px rgba(15,110,86,0.06)` halo.
- **`<AnswerCardFull>`** — full panel with citation pills inline (`<span class="cite">`), confidence dot in header, latency (mono, tertiary), footer with chunk count + feedback buttons + copy. Comment input slides in below footer on thumbs-down.
- **Citation pill (`.cite`)** — inline-block, `--accent-surface` bg, mono 11 px, `radius: 6px`, 2 px / 8 px padding. Cursor pointer; hover → `#C7EBDD`; **active state pin: bg `#C7EBDD`**, persists until same pill clicked again. Clicking highlights matching `<SourceCard>` (active prop).
- **`<ConfidenceDot>`** — 8 × 8 round. Green if score ≥ 0.70, **amber with subtle 2 s pulse animation** if borderline.
- **IDK warning block** — flex (icon + text), `--warning-surface` bg, `--radius-md`, 14/16 px padding, `ti-alert-circle` 18 px on the left in `--warning-text`.
- **Suggestion pill** — same as example-pill: `--bg-surface`, `0.5 px` border, 999 px radius, 8 px / 16 px padding, 12 px font.

### Tables & lists
- **`<EvalRunsPage>` table** — header row 11 px uppercase tertiary, body rows 13 px, row hover `--bg-surface`. Numeric cells `mono`. Status column = success pill with leading dot. Config column = icon button that toggles a popover with the run's config JSON.
- **`<FailureRow>`** — `0.5px` border, 12 px radius, 16/20 px padding, 10 px gap. Question (13/500), meta row (pill + 3 mono scores + chevron). Chevron rotates 90° on expand. Expanded body: 2-column grid (Expected chunks / Retrieved chunks); each chunk has a colored left border (success/warning/danger by relevance).
- **`<GenFailureRow>`** — like FailureRow, but expanded body shows: Generated answer with `<mark>` hallucinated spans (bg `--danger-surface`, color `--danger-text`, 0/4 px padding, 3 px radius); Judge reasoning in a `--bg-surface` block; retrieved-context paths list.

### Feedback / utilities
- **`<Toast>`** stack — bottom-right, 24 px from edges. White card with leading icon (`ti-circle-check` for success, `ti-alert-triangle` for danger, `ti-info-circle` for info). 12/16 px padding, `--radius-lg`, `0.5px` border, soft shadow. Auto-dismiss 2 s, fade-up entry, fade-down exit (300 ms). Max 2 visible at once, newest on top.
- **`<EmptyState>`** — centered, 64 px tinted circle with 28 px icon, title (15/500/secondary), description (13/tertiary, max-width 360), optional code hint (mono in `--bg-surface` pill).
- **`<Skel>` + `<SearchSkeleton>` + `<MetricGridSkeleton>`** — shimmering bars. `linear-gradient(90deg, --bg-surface 0, --bg-hover 50%, --bg-surface 100%)` with `background-size: 200% 100%`, `shimmer 1.5s ease-in-out infinite`.
- **`<RunSelector>`** — dropdown trigger ("Run · Run 18 ▾"); panel lists every run with name + date + config. Click outside closes.

---

## Screens (every state described)

### 1. Search (`/search`)

#### 1.1 Empty / idle
- Vertically centered hero (14 vh top padding).
- Title 22/500 "Ask your knowledge base anything." + subtitle 14/tertiary "Search across GitLab handbook and Stripe documentation."
- 580 px-wide search bar (52 px tall, `0.5px` border, 14 px radius, autofocus, accent focus ring `0 0 0 3px rgba(15,110,86,0.08)`).
- 4 example pills below (`--bg-surface` bg, 999 px radius).
- "Press `/` to focus search from anywhere" — small mono hint.

#### 1.2 Loading
- Triggered by Enter, Search button, or example-pill click.
- Search bar slides to top of the content area; pills + hero fade out (200 ms).
- `<SearchSkeleton>` fades in (200 ms): shimmer answer-card with header / 4 body lines / footer, then 3-column shimmer source cards.
- "Search" button → "Searching" + inline spinner (12 × 12 white border-spinner, 700 ms linear).
- Typical duration 1.5 s (mock simulates with `setTimeout`). Spec timeout = 15 s; on timeout, render the error state below.

#### 1.3 Results (happy path)
- Answer card (`<AnswerCardFull>`) fades up from 10 px (300 ms).
- Body has inline `<span class="cite">Source N</span>` pills. Clicking one sets `activeCite = N` → matching `<SourceCard>` gets the active border + halo; clicking same pill again clears.
- Footer shows "5 chunks from 3 documents" + thumbs up / thumbs down / copy buttons.
- Source cards stagger in (300 ms each, 60 ms delay between).

#### 1.4 IDK ("I don't know")
- Triggered when query matches `IDK_TRIGGERS` regexes ("largest customer", "european subsidiary", "how many people work", "work visa", etc.) — server-side this corresponds to top similarity < threshold (0.45).
- Confidence dot is **amber with pulse**, not green.
- Warning block inside the answer body (see component).
- Footer: "0 chunks above relevance threshold". No source cards.
- Below: suggestions panel (white, `--radius-xl` border) with label "Try rephrasing, or browse related topics" + 3 reformulated-question pills. Clicking a pill re-submits.
- Fade-in delay 200 ms after answer card.

#### 1.5 Error
- Same panel structure as IDK but with `--danger-surface` block + "Try again" outlined button. Mock omits this state; implement as part of API error handling.

### 2. Retrieval dashboard (`/dashboard/retrieval`)

- Page header: title + subtitle, run selector on the right.
- 4 metric cards: Precision@5 · Recall@5 · MRR · Eval queries. Each shows delta vs the previous run (chronologically). Delta pill is success/danger based on direction; neutral if absolute diff < 0.005.
- "Precision@5 across runs" panel — `<HighlightedTrendChart>` with current run highlighted (r=7 + accent halo + bold/colored x-axis label).
- "Category breakdown" panel — `<BarRow>` for each of single-doc / ambiguous / multi-doc / unanswerable / contradictory. Sort by value descending (not alpha).
- "Failure explorer" panel — sub-tabs (Worst P@5 / Worst R@5 / Unanswerable) on the right of the panel header. Body is a list of `<FailureRow>` sorted by the active metric ascending.
- Empty state: when `eval_runs` is empty, show `<EmptyState>` with `ti-chart-bar` icon, "No eval runs yet", description, and a `<code>` hint: `python scripts/07_run_eval.py`.

### 3. Generation dashboard (`/dashboard/generation`)

- Same header pattern; run selector persists from Retrieval.
- 4 metric cards: Avg Faithfulness ("3.8 / 5"), Avg Completeness, Hallucination Rate (always `--danger`, no delta badge, desc "18 of 100 questions"), Avg Relevance.
- "Score distributions" — `<ScoreHistogram>` (Faithfulness / Completeness / Hallucination [binary] / Relevance).
- "Faithfulness by category" — `<BarRow>` per category.
- "Generation failures" — list of `<GenFailureRow>` (expandable). Hallucinated text is the **most important visual moment** — `<mark>` with `--danger-surface` background. Judge reasoning block sits below.

### 4. Product metrics (`/dashboard/metrics`)

- Page header + range selector (segmented control: Last 7 days / Last 30 days / All time).
- 4 metric cards: Total queries · Satisfaction rate · Avg latency · Follow-up rate.
- "Daily query volume" — `<BarChart>` (not a line chart). Bar growth stagger.
- "Satisfaction trend" — line chart with **dashed target line at 80%**.
- "Latency trend" — line chart with **dashed target line at 2.0 s**. Line color shifts to `--warning` if latest > target, `--accent` if at/below.
- Empty state: "No queries logged yet. Ask some questions on the Search page to start seeing product metrics."

### 5. Eval runs (`/eval-runs`)

- Table: Run name (with "current" accent pill) · Date · P@5 · R@5 · Faith · Halluc. (color-coded pill) · Status (success pill with leading dot — variants for `running` amber+animated, `failed` red, `rate_limited` amber) · Config (icon button → popover with full run config JSON, dismisses on click-outside).
- Top-right "Compare runs" button toggles compare mode → adds checkbox column. User selects exactly 2 rows. "Compare 2/2" CTA activates.
- Click row in non-compare mode → navigate to `/dashboard/retrieval?run={id}`.

#### 5.1 Comparison view (`/eval-runs/compare?a=&b=`)

Reached when 2 runs are selected and Compare is pressed.
- Back link: "← Back to eval runs".
- Title: "Comparing: {nameA} vs {nameB}". Subtitle has both dates + configs.
- "Metric deltas" panel — one row per metric: label · valueA → valueB · delta pill (improvement/regression/neutral). Hallucination treats lower-is-better.
- "What changed" config diff — mono lines with `from` (`--danger-surface`) → `to` (`--success-surface`) styling.
- "Precision@5 across all runs" — `<OverlayTrendChart>` with both runs highlighted (labeled "A" / "B" with value annotations).
- "Where they differ most" — table of per-question P@5 deltas, sorted by `abs(delta)` desc, with green/red text on the delta column.

### 6. Settings (`/settings`)

- Appearance: light/dark segmented toggle (`ti-sun` / `ti-moon` icons).
- Data sources: read-only rows for each indexed corpus — name, mono stats ("2,847 documents · 12,340 chunks"), last-sync timestamp, success "connected" pill. Re-ingest pill-button at the bottom.
- Eval configuration: mono `<pre>`-style block with the full config JSON. "Copy config" outlined button in the panel header right slot → toast.
- About: name + version + build pill + GitHub / Case study link pills.

---

## Interactions & behavior

### Search

| Trigger | Behavior |
|---|---|
| Type in search bar + Enter | Submit query |
| Click "Search" button | Submit query |
| Click example pill | Fill search bar + auto-submit |
| Press `/` anywhere | Focus search bar |
| Empty submit | No-op |
| Click `[Source N]` citation | Toggle active state on matching `<SourceCard>` |
| Click thumbs-up | Icon turns green, button bg `--success-surface`, disable thumbs-down, toast "Thanks for your feedback" (2 s) |
| Click thumbs-down | Icon turns red, button bg `--danger-surface`, disable thumbs-up, slide in comment input ("What went wrong? (optional)"). Submit → toast |
| Click copy | Copy answer plain-text (sans citation markup) to clipboard, icon → `ti-check` for 1100 ms, toast "Answer copied to clipboard" |
| Click "View original" | Open source URL in new tab |
| Submit new query | Re-enter loading state; search bar stays at top |
| Click X button | Reset to empty hero, refocus input |

### Dashboard

| Trigger | Behavior |
|---|---|
| Change run in selector | All panels fade out 100 ms, swap data, fade in 200 ms |
| Hover trend chart dot | Tooltip with run name + value |
| Click trend chart dot | Switch selector to that run (treat dot as the same control surface) |
| Click failure row | Expand chevron rotates 90°, body slides in (250 ms). Only one row expanded at a time. Click again to collapse |
| Switch failure-explorer sub-tab | Re-sort/filter list with 200 ms fade-swap |
| Click metric card | No-op (display-only) |

### Eval runs

| Trigger | Behavior |
|---|---|
| Click Compare runs | Enter compare mode, add checkbox column |
| Tick 1 row | Counter shows "1 of 2 selected"; Compare button disabled |
| Tick 2 rows | Counter "2 of 2"; Compare activates |
| Click 3rd row | No-op (checkbox disabled when 2 selected) |
| Click Cancel | Exit compare mode, clear selections |
| Click row (non-compare) | Navigate to `/dashboard/retrieval?run={id}` |
| Click config icon | Toggle popover; click outside closes |

### Settings

| Trigger | Behavior |
|---|---|
| Click Light/Dark | Swap `data-theme` on `<html>`; persist to localStorage; **all CSS variables swap instantly** — no page reload |
| Click Copy config | Copy JSON to clipboard + toast |

---

## State management

### Global (Zustand / Context / etc.)

```ts
type GlobalState = {
  selectedEvalRunId: string;       // default: most recent run
  setSelectedEvalRunId: (id: string) => void;
  theme: 'light' | 'dark';          // persisted in localStorage('rag-ops-theme')
  setTheme: (t: 'light' | 'dark') => void;
};
```

### Page-level (per-route component)

- `SearchPage`: `query`, `phase: 'idle' | 'loading' | 'answer' | 'idk'`, `activeCite`, `feedback: 'up' | 'down' | null`, `comment`, `showComment`, `expanded` (for long answers).
- `RetrievalPage` / `GenerationPage`: `failTab`, `expandedFailureId`.
- `MetricsPage`: `range: '7d' | '30d' | 'all'`.
- `EvalRunsPage`: `compareMode`, `selected: Set<string>`, `comparing: { a, b } | null`, `openConfig: string | null`.

### Data fetching (recommended: React Query)

- `useEvalRuns()` → `eval_runs` list, sorted newest first
- `useEvalRun(id)` → single run + `eval_results` (drives all dashboard panels)
- `useProductMetrics(range)` → daily totals for the chosen window
- `useSearch(query)` → server endpoint returning `{ answer, citations, sources, latency_ms }`

Stale-while-revalidate: render cached dashboard immediately on mount, refetch in background.

---

## Data shapes

Match these one-for-one — the mock's `data.js` is the source of truth.

```ts
type EvalRun = {
  id: string;            // 'r6'
  name: string;          // 'Run 18'
  date: string;          // ISO date
  p5: number;            // 0–1
  r5: number;            // 0–1
  mrr: number;           // 0–1
  faithfulness: number;  // 0–5
  hallucination: number; // 0–1 (rate)
  config: 'production' | 'experiment' | 'baseline';
  current?: boolean;
};

type FailureResult = {
  id: string;
  category: 'single-doc' | 'multi-doc' | 'unanswerable' | 'ambiguous' | 'contradictory';
  question: string;
  p5: number; r5: number; mrr: number;
  expected: string[];                                        // chunk paths
  retrieved: { path: string; rel: 'relevant' | 'tangential' | 'irrelevant' }[];
};

type GenerationFailure = {
  id: string;
  category: string;
  question: string;
  scores: { faith: number; comp: number; rel: number };     // each 1–5
  hallucinated: boolean;
  answer: string;
  halluc: string[];                                          // substrings inside `answer` to wrap in <mark>
  judge: string;                                             // judge reasoning text
  retrieved: { path: string; score: number }[];
};

type SearchAnswer = {
  question: string;
  latency: string;       // '1.8s'
  body: Array<{ text: string } | { cite: number }>;          // mixed segments
  sources: { id: number; score: number; path: string; content: string }[];
  count: string;         // '5 chunks from 3 documents'
};
```

---

## Logging contracts (mock not wired, but documented)

On search submit → INSERT into `queries`:
```
question, retrieved_chunk_ids, retrieved_scores,
generated_answer, citations, model_used, latency_ms,
user_feedback (null initially)
```

On thumbs up/down → UPDATE `queries` row:
```
user_feedback = 'positive' | 'negative'
feedback_comment = optional text
```

Dashboards are pure read views — no writes.

---

## Assets

No raster assets. No SVG illustrations. Icons are font-glyph (Tabler in mock → Lucide in production). Fonts are Google Fonts (Plus Jakarta Sans + JetBrains Mono).

---

## File index

`design_reference/` contains the runnable mock. Open `index.html` directly or serve the folder.

| File | What it is |
|---|---|
| `index.html` | Shell — loads React, Babel, Tabler webfont, scripts in order |
| `src/colors_and_type.css` | All design tokens (light + dark themes) + base type |
| `src/theme.css` | Component styles (sidebar, panel, metric card, search bar, tables, etc.) |
| `src/extras.css` | Additional styles for skeletons, toasts, comparison view, gen-failures, range selector |
| `src/data.js` | All mock data (`EVAL_RUNS`, `CATEGORIES`, `FAILURES`, `GEN_FAILURES_FULL`, `SAMPLE_ANSWER`, `SAMPLE_IDK`, `METRICS_SERIES`) |
| `src/components.jsx` | Shared primitives: Sidebar, PageHeader, RunSelector, MetricCard, Panel, Pill, BarRow, TrendChart, ScoreHistogram, FailureRow, SourceCard, AnswerCard |
| `src/extras.jsx` | Additional: Skel, SearchSkeleton, ToastProvider/useToast, EmptyState, ConfidenceDot, CompareView, OverlayTrendChart, GenFailureRow, HighlightedTrendChart |
| `src/SearchPage.jsx` | Search journey (empty → loading → answer → IDK) |
| `src/RetrievalPage.jsx` | Retrieval dashboard |
| `src/GenerationPage.jsx` | Generation dashboard |
| `src/MetricsPage.jsx` | Product metrics dashboard + BarChart + TrendChartWithTarget |
| `src/EvalRunsPage.jsx` | Eval runs table + compare mode |
| `src/SettingsPage.jsx` | Settings |
| `src/app.jsx` | App shell — routing, theme persistence, Tweaks panel |
| `src/tweaks-panel.jsx` | (Mock-only — design exploration panel; not part of the product surface) |

---

## Production checklist

- [ ] Route `/` to `/search` (default landing).
- [ ] Deep-link `?run={id}` on dashboards; keep selector synced with URL.
- [ ] Deep-link `?q=` on `/search` (auto-submits on load).
- [ ] Theme toggle persists in `localStorage`; honor `prefers-color-scheme` only if no stored value.
- [ ] Skeleton loaders show on any first paint (no spinners — see Visual foundations).
- [ ] Failure rows are keyboard-accessible (`role="button"`, `aria-expanded`, Enter to toggle, Escape to collapse).
- [ ] `/` keyboard shortcut focuses the search bar from anywhere; ignore when an input is already focused.
- [ ] All metric values have `sr-only` context (e.g., "0.74 out of 1.0").
- [ ] Charts have fallback text descriptions.
- [ ] Toasts are announced via `aria-live="polite"`.
- [ ] Color-coded elements (pills, hallucination marks, confidence dot) carry a text equivalent for screen readers.
- [ ] Hallucination text in the generation explorer uses both color AND `<mark>` semantics.
