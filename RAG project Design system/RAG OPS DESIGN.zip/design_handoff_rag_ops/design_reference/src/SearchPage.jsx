// Search page — empty hero → loading → answer card + sources OR IDK with suggestions.
const { useState: useStateSearch, useEffect: useEffectSearch, useRef: useRefSearch } = React;

function SearchPage() {
  const D = window.RAG_DATA;
  const toast = useToast();
  const [query, setQuery] = useStateSearch('');
  const [phase, setPhase] = useStateSearch('idle'); // idle | loading | answer | idk
  const [activeCite, setActiveCite] = useStateSearch(null);
  const [feedback, setFeedback] = useStateSearch(null);
  const [showComment, setShowComment] = useStateSearch(false);
  const [comment, setComment] = useStateSearch('');
  const [expanded, setExpanded] = useStateSearch(false);
  const inputRef = useRefSearch(null);

  function submit(q) {
    const text = (q || query).trim();
    if (!text) return;
    setQuery(text);
    setActiveCite(null);
    setFeedback(null);
    setShowComment(false);
    setComment('');
    setExpanded(false);
    setPhase('loading');
    const isIdk = D.IDK_TRIGGERS.some(re => re.test(text));
    const delay = 1100 + Math.random() * 700;
    setTimeout(() => setPhase(isIdk ? 'idk' : 'answer'), delay);
  }

  function onFeedback(kind) {
    setFeedback(kind);
    if (kind === 'down') {
      setShowComment(true);
    } else {
      setShowComment(false);
      toast.push('Thanks for your feedback', 'success');
    }
  }
  function submitComment() {
    setShowComment(false);
    toast.push('Thanks for your feedback', 'success');
  }
  function copyAnswer() {
    try { navigator.clipboard.writeText(D.SAMPLE_ANSWER.body.filter(s => s.text).map(s => s.text).join('')); } catch (e) {}
    toast.push('Answer copied to clipboard', 'success');
  }

  function reset() {
    setPhase('idle');
    setQuery('');
    setActiveCite(null);
    setFeedback(null);
    setShowComment(false);
    setTimeout(() => inputRef.current && inputRef.current.focus(), 50);
  }

  useEffectSearch(() => {
    function onKey(e) {
      if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && inputRef.current) {
        e.preventDefault();
        inputRef.current.focus();
      }
    }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  // Empty / idle state
  if (phase === 'idle') {
    return (
      <div className="page">
        <div className="search-empty">
          <h1>Ask your knowledge base anything.</h1>
          <div className="sub">Search across GitLab handbook and Stripe documentation.</div>
          <div className="bar-wrap">
            <div className="search-bar">
              <i className="ti ti-search" style={{ fontSize: 18, color: 'var(--text-tertiary)' }} />
              <input
                ref={inputRef}
                placeholder="What is the home-office stipend at GitLab?"
                value={query}
                onChange={e => setQuery(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && submit()}
                aria-label="Search the knowledge base"
                autoFocus
              />
              <button className="btn-primary" onClick={() => submit()}>Search</button>
            </div>
            <div className="example-pills">
              {D.EXAMPLE_QUESTIONS.map(q => (
                <button key={q} className="example-pill" onClick={() => submit(q)}>{q}</button>
              ))}
            </div>
            <div style={{ textAlign: 'center', marginTop: 24, fontSize: 11, color: 'var(--text-tertiary)' }}>
              Press <kbd style={{ fontFamily: 'var(--font-mono)', background: 'var(--bg-surface)', padding: '2px 6px', borderRadius: 4, border: '0.5px solid var(--border-light)' }}>/</kbd> to focus search from anywhere
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Post-submit: search bar at top, then results
  return (
    <div className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
        <div className="search-bar" style={{ flex: 1 }}>
          <i className="ti ti-search" style={{ fontSize: 18, color: 'var(--text-tertiary)' }} />
          <input
            ref={inputRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && submit()}
            aria-label="Search the knowledge base"
          />
          <button
            className={'btn-primary' + (phase === 'loading' ? ' loading' : '')}
            onClick={() => submit()}
          >{phase === 'loading' ? 'Searching' : 'Search'}</button>
        </div>
        <button className="btn-icon" title="New search" onClick={reset} aria-label="Clear and start a new search">
          <i className="ti ti-x" style={{ fontSize: 15 }} />
        </button>
      </div>

      {phase === 'loading' && <SearchSkeleton />}

      {phase === 'answer' && (
        <>
          <AnswerCardFull
            answer={D.SAMPLE_ANSWER}
            activeCite={activeCite}
            setActiveCite={setActiveCite}
            onFeedback={onFeedback}
            feedback={feedback}
            onCopy={copyAnswer}
            expanded={expanded}
            setExpanded={setExpanded}
            showComment={showComment}
            comment={comment}
            setComment={setComment}
            submitComment={submitComment}
          />
          <div className="source-grid">
            {D.SAMPLE_ANSWER.sources.map((s, i) => (
              <div className="fade-up" key={s.id} style={{ animationDelay: `${i * 60}ms` }}>
                <SourceCard
                  src={s}
                  active={activeCite === s.id}
                  onClick={() => setActiveCite(activeCite === s.id ? null : s.id)}
                />
              </div>
            ))}
          </div>
        </>
      )}

      {phase === 'idk' && (
        <>
          <div className="panel fade-up">
            <div className="panel-header">
              <div className="title-row">
                <h3>Answer</h3>
                <ConfidenceDot score={0.32} />
              </div>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-tertiary)' }}>0.9s</span>
            </div>
            <div className="panel-body">
              <div className="idk-warn">
                <i className="ti ti-alert-circle" />
                <div className="msg">{D.SAMPLE_IDK.body}</div>
              </div>
            </div>
            <div style={{ padding: '14px 20px', borderTop: '0.5px solid var(--border-light)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>0 chunks above relevance threshold</span>
              <div style={{ display: 'flex', gap: 6 }}>
                <button
                  className={'btn-icon' + (feedback === 'up' ? ' active-up' : '')}
                  disabled={feedback === 'down'}
                  style={feedback === 'down' ? { opacity: 0.4 } : null}
                  onClick={() => onFeedback('up')}
                  aria-label="Rate this answer as helpful"
                ><i className="ti ti-thumb-up" style={{ fontSize: 15 }} /></button>
                <button
                  className={'btn-icon' + (feedback === 'down' ? ' active-down' : '')}
                  disabled={feedback === 'up'}
                  style={feedback === 'up' ? { opacity: 0.4 } : null}
                  onClick={() => onFeedback('down')}
                  aria-label="Rate this answer as unhelpful"
                ><i className="ti ti-thumb-down" style={{ fontSize: 15 }} /></button>
              </div>
            </div>
            {showComment && (
              <div className="feedback-comment">
                <input
                  placeholder="What went wrong? (optional)"
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && submitComment()}
                  autoFocus
                />
                <button onClick={submitComment}>Submit</button>
              </div>
            )}
          </div>

          <div className="suggestions-panel">
            <div className="label">Try rephrasing, or browse related topics</div>
            <div className="row">
              {D.SAMPLE_IDK.suggestions.map(s => (
                <button key={s} className="example-pill" onClick={() => submit(s)}>{s}</button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// Enhanced answer card with citation highlighting, copy, feedback comment, show-more
function AnswerCardFull({ answer, activeCite, setActiveCite, onFeedback, feedback, onCopy, expanded, setExpanded, showComment, comment, setComment, submitComment }) {
  const [copied, setCopied] = useStateSearch(false);
  function handleCopy() {
    onCopy();
    setCopied(true);
    setTimeout(() => setCopied(false), 1100);
  }
  return (
    <div className="panel fade-up" style={{ marginBottom: 20 }}>
      <div className="panel-header">
        <div className="title-row">
          <h3>Answer</h3>
          <ConfidenceDot score={0.82} />
        </div>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-tertiary)' }}>{answer.latency}</span>
      </div>
      <div className="panel-body" style={{ fontSize: 14, color: 'var(--text-primary)', lineHeight: 1.8 }}>
        {answer.body.map((seg, i) => seg.cite
          ? <span
              key={i}
              className="cite"
              style={ activeCite === seg.cite ? { background: '#C7EBDD' } : null }
              onClick={() => setActiveCite(activeCite === seg.cite ? null : seg.cite)}
            >Source {seg.cite}</span>
          : <span key={i}>{seg.text}</span>
        )}
      </div>
      <div style={{ padding: '14px 20px', borderTop: '0.5px solid var(--border-light)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>{answer.count}</span>
        <div style={{ display: 'flex', gap: 6 }}>
          <button
            className={'btn-icon' + (feedback === 'up' ? ' active-up' : '')}
            disabled={feedback === 'down'}
            style={feedback === 'down' ? { opacity: 0.4 } : null}
            onClick={() => onFeedback('up')}
            aria-label="Rate this answer as helpful"
          ><i className="ti ti-thumb-up" style={{ fontSize: 15 }} /></button>
          <button
            className={'btn-icon' + (feedback === 'down' ? ' active-down' : '')}
            disabled={feedback === 'up'}
            style={feedback === 'up' ? { opacity: 0.4 } : null}
            onClick={() => onFeedback('down')}
            aria-label="Rate this answer as unhelpful"
          ><i className="ti ti-thumb-down" style={{ fontSize: 15 }} /></button>
          <button className="btn-icon" onClick={handleCopy} aria-label="Copy answer to clipboard">
            <i className={'ti ' + (copied ? 'ti-check' : 'ti-copy')} style={{ fontSize: 15, color: copied ? 'var(--success)' : undefined }} />
          </button>
        </div>
      </div>
      {showComment && (
        <div className="feedback-comment">
          <input
            placeholder="What went wrong? (optional)"
            value={comment}
            onChange={e => setComment(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && submitComment()}
            autoFocus
          />
          <button onClick={submitComment}>Submit</button>
        </div>
      )}
    </div>
  );
}

window.SearchPage = SearchPage;
