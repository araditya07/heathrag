// Settings page — appearance, data sources, eval config, about.
function SettingsPage({ theme, setTheme }) {
  const config = `{
  "chunk_size":       1024,
  "chunk_overlap":    128,
  "embedding_model":  "text-embedding-3-large",
  "retriever":        "hybrid (bm25 + cohere-rerank-3.5)",
  "retriever_k":      5,
  "reranker_enabled": true,
  "threshold":        0.45,
  "judge_model":      "claude-3.7-sonnet",
  "eval_queries":     100
}`;
  const toast = useToast();
  function copyConfig() {
    try { navigator.clipboard.writeText(config); } catch (e) {}
    toast.push('Config copied to clipboard', 'success');
  }

  return (
    <div className="page">
      <PageHeader title="Settings" subtitle="Appearance, sources, eval configuration." />

      <Panel title="Appearance" subtitle="Theme is persisted per browser">
        <div className="settings-section">
          <div className="theme-segment">
            <button className={theme === 'light' ? 'active' : ''} onClick={() => setTheme('light')}>
              <i className="ti ti-sun" />Light
            </button>
            <button className={theme === 'dark' ? 'active' : ''} onClick={() => setTheme('dark')}>
              <i className="ti ti-moon" />Dark
            </button>
          </div>
        </div>
      </Panel>

      <Panel title="Data sources" subtitle="Indexed corpora">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <SourceRow
            name="GitLab handbook"
            stats="2,847 documents \u00b7 12,340 chunks"
            lastSync="last sync 2 hours ago"
          />
          <SourceRow
            name="Stripe documentation"
            stats="683 documents \u00b7 4,201 chunks"
            lastSync="last sync 5 hours ago"
          />
          <button className="example-pill" style={{ alignSelf: 'flex-start', marginTop: 4 }}>
            <i className="ti ti-refresh" style={{ fontSize: 13, marginRight: 6 }} />Re-ingest sources
          </button>
        </div>
      </Panel>

      <Panel title="Eval configuration" subtitle="Set via CLI \u2014 read-only here"
        right={
          <button className="example-pill" onClick={copyConfig}>
            <i className="ti ti-copy" style={{ fontSize: 13, marginRight: 6 }} />Copy config
          </button>
        }
      >
        <div className="config-block">{config}</div>
      </Panel>

      <Panel title="About">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)' }}>RAG Ops</div>
              <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 2 }}>v1.0.0 \u00b7 internal observability for retrieval-augmented systems</div>
            </div>
            <span className="pill neutral mono">build 1834</span>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="example-pill"><i className="ti ti-brand-github" style={{ fontSize: 13, marginRight: 6 }} />GitHub</button>
            <button className="example-pill"><i className="ti ti-file-text" style={{ fontSize: 13, marginRight: 6 }} />Case study</button>
          </div>
        </div>
      </Panel>
    </div>
  );
}

function SourceRow({ name, stats, lastSync }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '14px 16px', background: 'var(--bg-surface)',
      borderRadius: 'var(--radius-md)',
    }}>
      <div>
        <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)' }}>{name}</div>
        <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 2, fontFamily: 'var(--font-mono)' }}>{stats}</div>
        <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 2 }}>{lastSync}</div>
      </div>
      <Pill kind="success"><i className="ti ti-circle-check" style={{ fontSize: 11, marginRight: 2 }} />connected</Pill>
    </div>
  );
}

window.SettingsPage = SettingsPage;
