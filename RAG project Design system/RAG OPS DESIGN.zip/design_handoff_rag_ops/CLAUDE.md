# Claude Code: implementation guidance for RAG Ops

Read `README.md` first — it's the spec. This file is a short note to the Claude Code agent on how to approach implementation.

## Start here

1. **Open `design_reference/index.html` in a browser** to see the prototype running. Click through every nav item. Trigger the IDK path (search for "largest customer" or "work visa"). Try Compare mode in Eval runs. Toggle dark mode in Settings. Open the Tweaks panel.

2. **Read the spec** — `README.md` documents every screen, state, transition, and design token.

3. **Inspect the source** — `design_reference/src/` is the runnable React+Babel mock. Treat it as visual reference, not code to lift directly.

## Recreate, don't copy

The mock uses inline React + Babel via CDN. Your target codebase almost certainly has:
- A bundler (Vite / Next / Webpack)
- A typed component model (TypeScript)
- A styling system (Tailwind / CSS Modules / styled-components / Panda / etc.)
- A data-fetching layer (React Query / SWR / RTK)
- A routing layer (React Router / Next App Router / TanStack Router)

Use the existing patterns. Port the **design tokens** (`design_reference/src/colors_and_type.css`) one-for-one — those are locked. Port the **component shapes** (Sidebar, Panel, MetricCard, FailureRow, etc.) using the codebase's idioms.

## Lock these

- Hex values, radii, font weights, animation durations
- Tabler-icon → Lucide-icon mapping (see spec)
- Copy: page titles, microcopy, empty-state text, toast messages, the IDK warning ("I don't have enough information…")
- Information architecture: 6 routes, sidebar structure, the eval-run selector pattern shared by Retrieval/Generation
- Data shapes: `EvalRun`, `FailureResult`, `GenerationFailure`, `SearchAnswer` (see README)

## Substitute these

- **Chart library** — Recharts / Visx / nivo for production. Reproduce visual specs (current-run highlight, target reference lines, accent gradient fills).
- **Icon library** — Lucide React, per Tabler→Lucide map in the design system spec.
- **State** — Zustand / Redux Toolkit / Context.
- **Routing** — whatever the app uses.

## Don't add what isn't here

- No marketing copy.
- No emoji.
- No bouncy / spring animations.
- No backdrop-filter blur or glassmorphism.
- No card shadows in light theme (the border + tinted page bg provides depth).
- No font-weight 700 anywhere.

## Visual rhythm cheat sheet

- Page background: `--bg-page` (warm off-white in light, near-black in dark). NEVER pure white.
- Cards float on the tinted background. Two flavors: white panel (with `0.5px` border) or tinted metric card (no border, the tint IS the separation).
- Accent green is precious — primary CTAs, active nav, trend lines, citation pills, the relevant-chunk marker. **Everything else uses the semantic palette as pill bg + text only.**
- Numbers are mono. Latencies are `1.8s` not `1800ms`. Percentages have no decimals unless meaningful.

## Order of operations (suggested)

1. Port design tokens — get colors, type, spacing, radii into your token system.
2. Build the Sidebar + app shell + theme toggle (data-theme attribute on root).
3. Build the primitives in this order: `Panel`, `MetricCard`, `Pill`, `BarRow`, `Skeleton`, `Toast`.
4. Build the Search page end-to-end (it exercises every primitive plus the IDK branch).
5. Build dashboards in order: Retrieval → Generation → Metrics. They share the `<PageHeader>` + `<RunSelector>` + `<MetricCard>` infrastructure.
6. Build Eval runs table → Compare view last (uses everything else).
7. Wire data fetching and replace mock data with real endpoints.

## Acceptance criteria

If a screenshot of your implementation overlaid on the corresponding mock screen drifts noticeably in any of these, fix it before declaring done:
- Color values (incl. semantic surfaces)
- Card radii and border thickness
- Typography (especially mono-vs-display switches and weight)
- Spacing between sections (20 px) and inside cards (16/18/20)
- Skeleton shimmer animation
- Citation-pill ↔ source-card highlight interaction
- IDK confidence dot color (amber, not green) and the suggestion-pill panel below it
- Hallucination `<mark>` styling — bg `--danger-surface`, text `--danger-text`, 3 px radius
- Trend chart current-run highlight (r=7 + accent halo)
